import hyphae.cli
if __name__ == "__main__":
    hyphae.cli.main()
    